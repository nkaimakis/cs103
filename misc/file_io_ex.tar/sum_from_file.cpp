#include <iostream>
#include <fstream>

using namespace std;

int main(int argc, char *argv[])
{
  ifstream ifile("num2.txt");
  int x, y;



  cout << "X=" << x << " and Y=" << y << endl;

  return 0;
}
